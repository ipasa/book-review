<?php
include 'connection/dbconnect.php';

  $userNewID  = $_GET['userID'];
  $bookID     = $_GET['itemID'];
  $rating     = $_GET['score'];

  // For random data INSERT
  // $userNewID  = rand(1,30);
  // $bookID     = rand(1,100);
  // $bookRating = rand(0,10);
  //
  // $sql = "INSERT INTO comments (user_id, book_id, score_tag) VALUES ($userNewID,$bookID,$bookRating)";
  // mysqli_query($conn, $sql);

  // Rating Update on Ratings table
  if (mysqli_num_rows(mysqli_query($conn, "SELECT rating FROM ratings WHERE book_id=$bookID")) >0) {

    $previousRating = "SELECT rating FROM ratings WHERE book_id=$bookID";
    $db_result  = mysqli_query($conn, $previousRating);
    $row=mysqli_fetch_assoc($db_result);
    $updatedRating  = $row['rating']+$rating;

    $ratingUpdate = "UPDATE ratings
                      SET rating=$updatedRating, updated_at=now()
                      WHERE book_id=$bookID";
                      mysqli_query($conn, $ratingUpdate);
  }else {
    $sql = "INSERT INTO ratings (book_id, rating, created_at, updated_at) VALUES ($bookID,$rating, now(), now())";
    mysqli_query($conn, $sql);
  }



  // This code assumes $bookID isset to that of
  // the item that was just rated .
  // Get all of the user's rating pairs
  $sql = "SELECT DISTINCT r.book_id,(r2.score_tag-r.score_tag) AS rating_difference
          FROM comments r,comments r2
          WHERE r.user_id = $userNewID AND r2.book_id = $bookID AND r2.user_id = $userNewID";

  $db_result  = mysqli_query($conn, $sql);
  $num_rows   = mysqli_num_rows($db_result);

  //For every one o f the us e r ' s r a t i n g pa i r s ,
  //update the dev t a b l e

  while ($row=mysqli_fetch_assoc($db_result)) {
    $other_itemID       = $row['book_id'];
    $rating_difference  = $row ['rating_difference'] ;
    // if the pair ( $bookID , $other_itemID ) is already in
    // the dev t a b l e
    // then we want to update 2 rows .
    if (mysqli_num_rows(mysqli_query($conn, "SELECT itemID1
      FROM dev WHERE itemID1=$bookID AND itemID2=$other_itemID")) > 0){
        $sql = "UPDATE dev
                SET count=count+1,sum=sum+$rating_difference
                WHERE itemID1=$bookID AND itemID2=$other_itemID" ;
                mysqli_query($conn, $sql);
      //We only want to update i f the i tems ar e
      // d i f f e r e n t
      if( $bookID != $other_itemID ){
      $sql = "UPDATE dev SET count=count+1,sum=sum􀀀-$rating_difference
              WHERE(itemID1=$other_itemID AND itemID2=$bookID)" ;
      mysqli_query($conn, $sql);
      }
    }
    //we want to i n s e r t 2 rows int o the dev t a b l e
    else {
      $sql = "INSERT INTO dev VALUES ($bookID,$other_itemID,1, $rating_difference)";
      mysqli_query($conn, $sql);

      //We only want to i n s e r t i f the i tems ar e
      // d i f f e r e n t
      if($bookID != $other_itemID){
        $sql = "INSERT INTO dev VALUES ($other_itemID,$bookID,1,-$rating_difference)";
        mysqli_query($conn, $sql);
        }
      }
  }
  header('Location: http://localhost:8000/book/'.$bookID);
mysqli_close($conn);
?>
